import { Heart, ArrowUp, Zap, Mail, MapPin, Instagram, Twitter, Music, Youtube } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

import logo from '@/assets/logo.jpg';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-t from-background to-muted/30 border-t border-accent/20">
      <div className="container mx-auto px-4 py-16">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2 space-y-6">
            <div className="flex items-center gap-3">
                <img
                  src={logo}
                  className="w-12 h-12 rounded-lg object-cover"
                />
              <span className="text-2xl font-display font-bold text-gradient">BaNe</span>
            </div>
            <p className="text-muted-foreground leading-relaxed max-w-md">
              Collettivo creativo che unisce musica elettronica, sviluppo web e arte visiva. 
              Creiamo esperienze che vanno oltre i confini tradizionali dell'arte digitale.
            </p>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="hover:bg-accent hover:text-accent-foreground" asChild>
                <a href="https://instagram.com/polodellafocetrap" target="_blank" rel="noopener noreferrer">
                  <Instagram className="h-4 w-4" />
                </a>
              </Button>
              {/* <Button variant="outline" size="sm" className="hover:bg-accent hover:text-accent-foreground" asChild>
                <a href="https://twitter.com/bane_collective" target="_blank" rel="noopener noreferrer">
                  <Twitter className="h-4 w-4" />
                </a>
              </Button> */}
              <Button variant="outline" size="sm" className="hover:bg-accent hover:text-accent-foreground" asChild>
                <a href="https://youtube.com/@banerecords8675" target="_blank" rel="noopener noreferrer">
                  <Youtube className="h-4 w-4" />
                </a>
              </Button>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-6">
            <h3 className="font-display font-semibold text-foreground text-lg">Esplora</h3>
            <div className="space-y-3">
              <Link to="/" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Home</span>
              </Link>
              <Link to="/about" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Chi Siamo</span>
              </Link>
              <Link to="/music" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Musica</span>
              </Link>
              {/* <Link to="/projects" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Progetti</span>
              </Link> */}
              <Link to="/gallery" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Galleria</span>
              </Link>
              <Link to="/contact" className="block text-muted-foreground hover:text-accent transition-colors group">
                <span className="story-link">Contatti</span>
              </Link>
            </div>
          </div>

          {/* Contact Info */}
          <div className="space-y-6">
            <h3 className="font-display font-semibold text-foreground text-lg">Contatti</h3>
            <div className="space-y-4">
              <a 
                href="mailto:bane@bane.com"
                className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors group"
              >
                <div className="p-2 bg-muted rounded-lg group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                  <Mail className="h-4 w-4" />
                </div>
                <span className="text-sm">bane@bane.com</span>
              </a>
              <a 
                href="https://maps.google.com/?q=Toscolano Maderno,+Italia"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-muted-foreground hover:text-accent transition-colors group"
              >
                <div className="p-2 bg-muted rounded-lg group-hover:bg-accent group-hover:text-accent-foreground transition-colors">
                  <MapPin className="h-4 w-4" />
                </div>
                <span className="text-sm">Toscolona Maderno, Italia</span>
              </a>
            </div>
          </div>
        </div>

        <Separator className="bg-accent/20" />
        
        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center pt-8 text-sm text-muted-foreground">
          <p>&copy; 2024 BaNe Collective. Tutti i diritti riservati.</p>
          <div className="flex gap-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-accent transition-colors story-link">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors story-link">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;