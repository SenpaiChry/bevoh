import { ExternalLink, Github } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import projectImage from '@/assets/project1.jpg';

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: "Sonic Visualizer",
      description: "Un'applicazione web interattiva che trasforma la musica in arte visiva attraverso algoritmi di visualizzazione in tempo reale.",
      image: projectImage,
      technologies: ["React", "Three.js", "Web Audio API", "TypeScript"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: true
    },
    {
      id: 2,
      title: "Digital Art Gallery",
      description: "Galleria d'arte digitale immersiva con realtà virtuale per esporre opere d'arte in spazi tridimensionali.",
      image: projectImage,
      technologies: ["Next.js", "WebXR", "Blender", "MongoDB"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: false
    },
    {
      id: 3,
      title: "Music AI Composer",
      description: "Intelligenza artificiale che compone musica originale basata sui generi e stili musicali preferiti dall'utente.",
      image: projectImage,
      technologies: ["Python", "TensorFlow", "MIDI", "Flask"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: true
    },
    {
      id: 4,
      title: "Creative Portfolio CMS",
      description: "Sistema di gestione contenuti personalizzato per artisti e creativi con builder drag-and-drop.",
      image: projectImage,
      technologies: ["Vue.js", "Node.js", "PostgreSQL", "AWS S3"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: false
    },
    {
      id: 5,
      title: "Interactive Music Video",
      description: "Video musicale interattivo dove l'utente può influenzare visuals e storyline attraverso input in tempo reale.",
      image: projectImage,
      technologies: ["WebGL", "P5.js", "Socket.io", "Node.js"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: false
    },
    {
      id: 6,
      title: "NFT Art Marketplace",
      description: "Marketplace per NFT artistici con sistema di aste automatizzate e gallerie virtuali personalizzabili.",
      image: projectImage,
      technologies: ["React", "Solidity", "IPFS", "Ethereum"],
      demoLink: "https://demo.example.com",
      codeLink: "https://github.com/example",
      featured: true
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-7xl">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gradient">
            I Nostri Progetti
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Una selezione dei nostri lavori più significativi che dimostrano la fusione tra arte, tecnologia e innovazione.
          </p>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card 
              key={project.id} 
              className={`card-glow group overflow-hidden ${
                project.featured ? 'lg:col-span-2' : ''
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardContent className="p-0">
                {/* Project Image */}
                <div className="relative overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className={`w-full object-cover transition-transform duration-500 group-hover:scale-110 ${
                      project.featured ? 'h-64' : 'h-48'
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  
                  {/* Project Links Overlay */}
                  <div className="absolute inset-0 flex items-center justify-center gap-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <Button size="sm" className="btn-hero" asChild>
                      <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Demo
                      </a>
                    </Button>
                    <Button size="sm" variant="outline" className="backdrop-blur-sm" asChild>
                      <a href={project.codeLink} target="_blank" rel="noopener noreferrer">
                        <Github className="h-4 w-4 mr-2" />
                        Codice
                      </a>
                    </Button>
                  </div>

                  {/* Featured Badge */}
                  {project.featured && (
                    <div className="absolute top-4 left-4 px-3 py-1 bg-primary text-primary-foreground text-xs font-semibold rounded-full">
                      In Evidenza
                    </div>
                  )}
                </div>

                {/* Project Info */}
                <div className="p-6">
                  <h3 className="text-xl font-display font-semibold mb-3 text-foreground group-hover:text-primary transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                    {project.description}
                  </p>

                  {/* Technologies */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-1 bg-muted/50 text-muted-foreground text-xs rounded-md border border-border/30"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Project Links */}
                  <div className="flex gap-3">
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <a href={project.demoLink} target="_blank" rel="noopener noreferrer">
                        <ExternalLink className="h-4 w-4 mr-2" />
                        Visualizza
                      </a>
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1" asChild>
                      <a href={project.codeLink} target="_blank" rel="noopener noreferrer">
                        <Github className="h-4 w-4 mr-2" />
                        Codice
                      </a>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-6">
            Vuoi vedere tutti i nostri progetti? Visita il nostro GitHub!
          </p>
          <Button className="btn-hero" asChild>
            <a href="https://github.com" target="_blank" rel="noopener noreferrer">
              <Github className="h-5 w-5 mr-2" />
              Vedi tutti i progetti
              <ExternalLink className="h-4 w-4 ml-2" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Projects;