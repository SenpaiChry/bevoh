import { useState } from 'react';
import { Send, Mail, Phone, MapPin, Instagram, Youtube, Twitter, Music } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise(resolve => setTimeout(resolve, 1000));

    toast({
      title: "Messaggio inviato!",
      description: "Ti risponderemo al più presto. Grazie per averci contattato!",
    });

    setFormData({ name: '', email: '', message: '' });
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      value: "bane@bane.com",
      link: "mailto:bane@bane.com"
    },
    {
      icon: MapPin,
      title: "Indirizzo",
      value: "Toscolano Maderno, Italia",
      link: "https://maps.google.com/?q=Toscolano Maderno,+Italia"
    }
  ];

  const socialLinks = [
    {
      name: "Instagram",
      icon: Instagram,
      url: "https://instagram.com/polodellafocetrap",
      color: "hover:text-pink-500"
    },
    {
      name: "Twitter",
      icon: Twitter,
      url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
      color: "hover:text-blue-400"
    },
    {
      name: "TikTok",
      icon: Music,
      url: "https://tiktok.com/@banerecords",
      color: "hover:text-purple-500"
    },
    {
      name: "YouTube",
      icon: Youtube,
      url: "https://youtube.com/@banerecords8675",
      color: "hover:text-red-500"
    }
  ];

  return (
    <section className="py-20 px-4 bg-muted/20">
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gradient">
            Contatti
          </h2>
        </div>

        {/* Contact Info & Social at top */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
          {/* Contact Information */}
          <Card className="card-glow">
            <CardHeader>
              <CardTitle className="text-xl font-display text-gradient">
                Informazioni di contatto
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              {contactInfo.map((info) => {
                const IconComponent = info.icon;
                return (
                  <a
                    key={info.title}
                    href={info.link}
                    target={info.link.startsWith('http') ? '_blank' : undefined}
                    rel={info.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="flex items-center gap-4 p-4 rounded-lg bg-muted/30 hover:bg-muted/50 transition-colors group"
                    style={{position:"relative"}}
                  >
                    <div className="p-2 bg-primary/20 rounded-lg group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                      <IconComponent className="h-5 w-5" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">{info.title}</h3>
                      <p className="text-muted-foreground text-sm">{info.value}</p>
                    </div>
                  </a>
                );
              })}
            </CardContent>
          </Card>

          {/* Social Media */}
          <Card className="card-glow">
            <CardHeader>
              <CardTitle className="text-xl font-display text-gradient">
                Seguici sui social
              </CardTitle>
            </CardHeader>
            <CardContent className="flex items-center justify-center min-h-[200px]">
              <div className="grid grid-cols-2 gap-6 w-full max-w-xs">
                {socialLinks.map((social) => {
                  const IconComponent = social.icon;
                  return (
                    <a
                      key={social.name}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="social-link-large flex flex-col items-center justify-center gap-3 p-6 rounded-lg bg-muted/30 hover:bg-accent hover:text-accent-foreground transition-all group"
                      style={{zIndex:"10000"}}
                    >
                      <IconComponent className="h-8 w-8 group-hover:scale-110 transition-transform" />
                      <span className="font-medium text-sm text-center">{social.name}</span>
                    </a>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Unified Contact Form */}
        {/* <Card className="card-glow max-w-4xl mx-auto">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-display text-gradient">
              Invia un Messaggio
            </CardTitle>
            <p className="text-muted-foreground mt-2">
              Raccontaci la tua idea o proponi una collaborazione
            </p>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-foreground mb-2">
                    Nome completo
                  </label>
                  <Input
                    id="name"
                    name="name"
                    type="text"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="bg-muted/50"
                    placeholder="Il tuo nome"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-foreground mb-2">
                    Email
                  </label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="bg-muted/50"
                    placeholder="la-tua-email@esempio.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-foreground mb-2">
                  Messaggio o Proposta Progetto
                </label>
                <Textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={6}
                  className="bg-muted/50"
                  placeholder="Parlaci del tuo progetto, della tua idea o semplicemente inviaci un messaggio..."
                />
              </div>*/}

              {/* Project Types */}
              {/*<div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-6 bg-muted/20 rounded-lg">
                <div className="text-center p-4 rounded-lg hover:bg-accent/10 transition-colors cursor-pointer">
                  <div className="text-2xl mb-2">🎵</div>
                  <h4 className="font-semibold text-sm text-foreground">Progetti Musicali</h4>
                  <p className="text-xs text-muted-foreground">Produzione & Collaborazioni</p>
                </div>
                
                <div className="text-center p-4 rounded-lg hover:bg-accent/10 transition-colors cursor-pointer">
                  <div className="text-2xl mb-2">💻</div>
                  <h4 className="font-semibold text-sm text-foreground">Sviluppo Web</h4>
                  <p className="text-xs text-muted-foreground">Siti & Applicazioni</p>
                </div>
                
                <div className="text-center p-4 rounded-lg hover:bg-accent/10 transition-colors cursor-pointer">
                  <div className="text-2xl mb-2">🎨</div>
                  <h4 className="font-semibold text-sm text-foreground">Arte Visiva</h4>
                  <p className="text-xs text-muted-foreground">Design & Branding</p>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isSubmitting}
                className="btn-hero w-full"
              >
                {isSubmitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                    Invio in corso...
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4 mr-2" />
                    Invia messaggio
                  </>
                )}
              </Button>
            </form>
          </CardContent>
        </Card> */}
      </div>
    </section>
  );
};

export default Contact;