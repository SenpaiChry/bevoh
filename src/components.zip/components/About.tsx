import { useState } from 'react';
import { Music, Code, Palette } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';

import occhialiFabio from '@/assets/persone_occhiali/buz_occhiali.jpg';
import occhialiAle from '@/assets/persone_occhiali/axel_occhiali.jpg';
import occhialiGio from '@/assets/persone_occhiali/pacjo_occhiali.jpg';
import occhialiLuca from '@/assets/persone_occhiali/luca_occhiali.jpg';
import occhialiEdo from '@/assets/persone_occhiali/pac_occhiali.jpg';
import occhialiChri from '@/assets/persone_occhiali/senpai_occhiali.jpg';
import occhialiAndy from '@/assets/persone_occhiali/gabubag_occhiali.jpg';

import groupPhoto1 from '@/assets/gruppo/bane_come_beatles.jpg';
import groupPhoto2 from '@/assets/gruppo/culoni.jpg';

const About = () => {
  
  const groupPhotos = [
    {
      src: groupPhoto1,
      alt: "BaNe come Beatles"
    },
    {
      src: groupPhoto2,
      alt: "BaNe Culoni"
    }
  ];

  const members = [
    {
      name: "Gioele Sala",
      role: "Musicista & Producer",
      icon: "🎵",
      image: occhialiGio,
      bio: "Compositore e produttore con 8 anni di esperienza. Specializzato in generi elettronici e ambient music.",
      iconComponent: Music,
      skills: ["Produzione Musicale", "Sound Design", "Mixing & Mastering"]
    },
    {
      name: "Edoardo Lucca", 
      role: "Frontend Developer",
      icon: "💻",
      image: occhialiEdo,
      bio: "Sviluppatrice frontend appassionata di UI/UX design. Crea esperienze web innovative e interattive.",
      iconComponent: Code,
      skills: ["React", "TypeScript", "3D Web", "Animation"]
    },
    {
      name: "Fabio Valli",
      role: "Visual Artist",
      icon: "🎨",
      image: occhialiFabio,
      bio: "Artista visivo e designer. Specializzato in arte digitale, branding e direzione creativa.",
      iconComponent: Palette,
      skills: ["Digital Art", "Branding", "Motion Graphics", "Photography"]
    },
    {
      name: "Andrea Gaburri",
      role: "Visual Artist",
      icon: "🎨",
      image: occhialiAndy,
      bio: "Artista visivo e designer. Specializzato in arte digitale, branding e direzione creativa.",
      iconComponent: Palette,
      skills: ["Digital Art", "Branding", "Motion Graphics", "Photography"]
    },
    {
      name: "Luca Baiguera",
      role: "Visual Artist",
      icon: "🎨",
      image: occhialiLuca,
      bio: "Artista visivo e designer. Specializzato in arte digitale, branding e direzione creativa.",
      iconComponent: Palette,
      skills: ["Digital Art", "Branding", "Motion Graphics", "Photography"]
    },
    {
      name: "Christian Colosio",
      role: "Visual Artist",
      icon: "🎨",
      image: occhialiChri,
      bio: "Artista visivo e designer. Specializzato in arte digitale, branding e direzione creativa.",
      iconComponent: Palette,
      skills: ["Digital Art", "Branding", "Motion Graphics", "Photography"]
    },
    {
      name: "Alessio Lesanti",
      role: "Visual Artist",
      icon: "🎨",
      image: occhialiAle,
      bio: "Artista visivo e designer. Specializzato in arte digitale, branding e direzione creativa.",
      iconComponent: Palette,
      skills: ["Digital Art", "Branding", "Motion Graphics", "Photography"]
    }
  ];

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gradient">
            Chi Siamo
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Un team di pro.
          </p>
        </div>

        {/* Group Photos Carousel */}
        <div className="mb-16">
          <Carousel className="max-w-4xl mx-auto">
            <CarouselContent>
              {groupPhotos.map((photo, index) => (
                <CarouselItem key={index}>
                  <div className="relative overflow-hidden rounded-2xl">
                    <img
                      src={photo.src}
                      alt={photo.alt}
                      className="w-full h-[400px] md:h-[500px] object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/60 via-transparent to-transparent" />
                    <div className="absolute bottom-6 left-6 right-6">
                      <p className="text-white text-lg font-medium">
                        {photo.alt}
                      </p>
                    </div>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="left-4" />
            <CarouselNext className="right-4" />
          </Carousel>
        </div>

        {/* Team Members Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {members.map((member, index) => {
            const IconComponent = member.iconComponent;
            return (
              <Card 
                key={member.name} 
                className="card-glow overflow-hidden group"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <CardContent className="p-0">
                  {/* Member Image */}
                  <div className="relative overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-64 object-cover transition-all duration-500 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
                    
                    {/* Icon Overlay */}
                    <div className="absolute top-4 right-4 p-3 bg-accent/20 backdrop-blur-sm rounded-full group-hover:bg-accent group-hover:text-accent-foreground transition-all duration-300">
                      <span className="text-lg">{member.icon}</span>
                    </div>
                  </div>

                  {/* Member Info */}
                  <div className="p-6">
                    <h3 className="text-xl font-display font-semibold mb-2 text-foreground">
                      {member.name}
                    </h3>
                    <p className="text-accent font-medium mb-3">
                      {member.role}
                    </p>
                    <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
                      {member.bio}
                    </p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2">
                      {member.skills.map((skill) => (
                        <span
                          key={skill}
                          className="px-3 py-1 bg-muted/50 text-muted-foreground text-xs rounded-full border border-border/30"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default About;