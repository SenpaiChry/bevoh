import { ArrowDown } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import heroImage from '@/assets/hero-new.jpg';

const Hero = () => {
  return (
    <section 
      id="home" 
      className="min-h-screen flex items-center justify-center relative overflow-hidden"
      style={{
        backgroundImage: `linear-gradient(135deg, rgba(220, 15, 4, 0.8), rgba(300, 76, 60, 0.8)), url(${heroImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundBlendMode: 'overlay'
      }}
    >
      {/* Background gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-background/20 via-transparent to-background/40" />
      
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4">
        {/* Main title */}
        <h1 className="text-9xl md:text-9xl font-display font-bold mb-6 animate-fade-in">
          <span className="text-gradient">Ba</span>
          <span className="text-secondary">Ne</span>
        </h1>

        {/* Subtitle */}
        {/* <p className="text-xl md:text-2xl text-foreground/80 mb-8 max-w-2xl mx-auto animate-fade-in animation-delay-200">
          "La creatività è contagiosa, trasmettila" - Einstein
        </p> */}

        {/* Description */}
        {/* <p className="text-lg text-foreground/70 mb-12 max-w-3xl mx-auto animate-fade-in animation-delay-400">
          Siamo BaNe, un gruppo di artisti, musicisti e sviluppatori uniti dalla passione per la creatività. 
          Creiamo esperienze uniche che mescolano arte, tecnologia e musica nel nostro stile distintivo.
        </p> */}

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in animation-delay-600">
          <Button
            asChild
            className="btn-hero group"
          >
            <Link to="/about">
              Scopri di più
              <ArrowDown className="ml-2 h-5 w-5 group-hover:animate-bounce-subtle" />
            </Link>
          </Button>
          
          <Button
            variant="outline"
            asChild
            className="border-2 border-primary/50 text-foreground hover:bg-primary hover:text-primary-foreground backdrop-blur-sm"
          >
            <Link to="/contact">
              Contattaci
            </Link>
          </Button>
        </div>
      </div>

      {/* Floating shapes */}
      <div className="absolute top-1/4 left-1/4 w-20 h-20 bg-primary/20 rounded-full animate-float" />
      <div className="absolute top-3/4 right-1/4 w-16 h-16 bg-secondary/20 rounded-full animate-float animation-delay-1000" />
      <div className="absolute top-1/2 right-1/3 w-12 h-12 bg-accent/20 rounded-full animate-float animation-delay-2000" />
    </section>
  );
};

export default Hero;