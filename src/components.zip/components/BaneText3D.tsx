import { useRef, useState, useEffect } from 'react';
import { Canvas, useFrame, ThreeEvent, useLoader } from '@react-three/fiber';
import { Center, Environment, Float } from '@react-three/drei';
import { OBJLoader } from 'three/examples/jsm/loaders/OBJLoader.js';
import * as THREE from 'three';

function BaneModel() {
  const meshRef = useRef<THREE.Group>(null);
  const [isDragging, setIsDragging] = useState(false);
  const previousMouse = useRef({ x: 0, y: 0 });
  
  const obj = useLoader(OBJLoader, '/models/LOGO_INTERO_3D.obj');

  useEffect(() => {
    if (obj) {
      obj.traverse((child) => {
        if (child instanceof THREE.Mesh) {
          // Smooth the geometry
          child.geometry.computeVertexNormals();
          
          child.material = new THREE.MeshLambertMaterial({
            color: '#f2f3f3',
            emissive: '#f2f3f3',
            emissiveIntensity: 0.2,
          });
        }
      });
    }
  }, [obj]);

  useFrame(() => {
    if (meshRef.current && !isDragging) {
      meshRef.current.rotation.y += 0.0005;
    }
  });

  const handlePointerDown = (e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    setIsDragging(true);
    previousMouse.current = { x: e.clientX, y: e.clientY };
    (e.target as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerUp = (e: ThreeEvent<PointerEvent>) => {
    setIsDragging(false);
    (e.target as HTMLElement).releasePointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: ThreeEvent<PointerEvent>) => {
    if (isDragging && meshRef.current) {
      const deltaX = e.clientX - previousMouse.current.x;
      const deltaY = e.clientY - previousMouse.current.y;
      
      meshRef.current.rotation.y += deltaX * 0.01;
      meshRef.current.rotation.x += deltaY * 0.01;
      
      previousMouse.current = { x: e.clientX, y: e.clientY };
    }
  };

  return (
    <group
      ref={meshRef}
      onPointerDown={handlePointerDown}
      onPointerUp={handlePointerUp}
      onPointerMove={handlePointerMove}
    >
      <Center>
        <Float
          speed={isDragging ? 0 : 2}
          rotationIntensity={isDragging ? 0 : 0.2}
          floatIntensity={isDragging ? 0 : 0.5}
        >
          <primitive object={obj} scale={5} />
        </Float>
      </Center>
    </group>
  );
}

export default function BaneText3D() {
  return (
    <div className="w-full h-screen bg-background cursor-grab active:cursor-grabbing">
      <Canvas
        camera={{ position: [0, 0, 8], fov: 50 }}
        gl={{ antialias: true, alpha: true }}
      >
        <color attach="background" args={['#0f0f0e']} />
        
        <ambientLight intensity={0.15} />
        <directionalLight
          position={[5, 5, 5]}
          intensity={0.4}
          color="#ffffff"
        />
        <directionalLight
          position={[-5, -3, -5]}
          intensity={2}
          color="#9d4f99"
        />
        <pointLight position={[0, 0, 5]} intensity={0.3} color="#ffffff" />
        
        <BaneModel />
        
        <Environment preset="city" />
      </Canvas>
      
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 text-muted-foreground text-sm tracking-widest uppercase opacity-60">
        Trascina per ruotare
      </div>
    </div>
  );
}