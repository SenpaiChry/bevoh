import { Play, Pause, ExternalLink } from 'lucide-react';
import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import defaultCover from '@/assets/album1.jpg';

import capodannoAllaFoceCover from '@/assets/songs_cover/capodanno_alla_foce.png';
import crocsVegetaCover from '@/assets/songs_cover/crocs_vegeta.png';
import gioMenestrelloCover from '@/assets/songs_cover/gio_menestrello.png';
import kiroFreestyleCover from '@/assets/songs_cover/kiro_freestyle.png';
import laFocePorcoDioCover from '@/assets/songs_cover/la_foce_porco_dio.png';
import ilSegretoDiGiannaCover from '@/assets/songs_cover/il_segreto_di_gianna.png';

import capodannoAllaFoce from '@/assets/songs/capodanno_alla_foce.mp3';
import crocsVegeta from '@/assets/songs/crocs_vegeta.mp3';
import gioMenestrello from '@/assets/songs/gio_menestrello.mp3';
import ilSegretoDiGianna from '@/assets/songs/il_segreto_di_gianna.mp3';
import kiroFreestyle from '@/assets/songs/kiro_freestyle.mp3';
import laFocePorcoDio from '@/assets/songs/la_foce_porco_dio.mp3';
import laPlaya from '@/assets/songs/la_playa.mp3';
import typeBeat1 from '@/assets/songs/type_beat_1.mp3';
import typeBeat2 from '@/assets/songs/type_beat_2.mp3';
import capodannoAllaFoceTypeBeat from '@/assets/songs/capodanno_alla_foce_type_beat.mp3';

const Music = () => {
  const [currentlyPlaying, setCurrentlyPlaying] = useState<number | null>(null);
  const audioRefs = useRef<(HTMLAudioElement | null)[]>([]);

  const songs = [
    {
      id: 1,
      title: "Capodanno alla foce",
      artist: "BaNe",
      duration: "2:15",
      cover: capodannoAllaFoceCover,
      audioUrl: capodannoAllaFoce, // Placeholder - in a real app you'd have audio files
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        youtube: "https://youtu.be/pd5ETv78VYI?si=LDt8TB1Ild4mBtAh",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 2,
      title: "Gio Menestrello",
      artist: "BaNe",
      duration: "3:13",
      cover: gioMenestrelloCover,
      audioUrl: gioMenestrello,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        youtube: "https://youtu.be/NnG3JiqGY_A?si=X0HTZ82EZZQyEPKr",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 3,
      title: "La Playa",
      artist: "BaNe",
      duration: "1:58",
      cover: defaultCover,
      audioUrl: laPlaya,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        // youtube: "https://youtube.com/",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 4,
      title: "Crocs Vegeta",
      artist: "BaNe",
      duration: "1:04",
      cover: crocsVegetaCover,
      audioUrl: crocsVegeta,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        youtube: "https://youtu.be/EYD49tk48-s?si=_57FcCMfE4OJdmqp",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 5,
      title: "La foce Porco d*o",
      artist: "BaNe",
      duration: "3:09",
      cover: laFocePorcoDioCover,
      audioUrl: laFocePorcoDio,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        youtube: "https://youtu.be/NtuQmE_TBbg?si=yI1S81jp1ib9fSLM",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 6,
      title: "Kiro Freestyle",
      artist: "BaNe",
      duration: "1:07",
      cover: kiroFreestyleCover,
      audioUrl: kiroFreestyle,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        youtube: "https://youtu.be/Yyy5rfDwjlk?si=1ApbNqG052IVtgmJ",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 7,
      title: "Il Segreto di Gianna",
      artist: "BaNe",
      duration: "3:03",
      cover: ilSegretoDiGiannaCover,
      audioUrl: ilSegretoDiGianna,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        // youtube: "https://youtube.com/",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 8,
      title: "Type Beat 1",
      artist: "BaNe",
      duration: "1:30",
      cover: defaultCover,
      audioUrl: typeBeat1,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        // youtube: "https://youtube.com/",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 9,
      title: "Type Beat 2",
      artist: "BaNe",
      duration: "2:31",
      cover: defaultCover,
      audioUrl: typeBeat2,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        // youtube: "https://youtube.com/",
        apple: "https://music.apple.com/"
      }
    },
    {
      id: 10,
      title: "Type Beat - Capodanno Alla foce",
      artist: "BaNe",
      duration: "1:23",
      cover: capodannoAllaFoceCover,
      audioUrl: capodannoAllaFoceTypeBeat,
      streamingLinks: {
        spotify: "https://open.spotify.com/",
        // youtube: "https://youtube.com/",
        apple: "https://music.apple.com/"
      }
    }
  ];

  const togglePlay = (songId: number, index: number) => {
    const audio = audioRefs.current[index];

    if (currentlyPlaying === songId) {
      audio?.pause();
      setCurrentlyPlaying(null);
    } else {
      // Pause all other audio
      audioRefs.current.forEach((audio, i) => {
        if (i !== index && audio) {
          audio.pause();
        }
      });

      audio?.play();
      setCurrentlyPlaying(songId);
    }
  };

  const streamingPlatforms = [
    // { name: "Spotify", icon: "🎵", key: "spotify" as const },
    { name: "YouTube", icon: "📺", key: "youtube" as const },
    // { name: "Apple Music", icon: "🎧", key: "apple" as const }
  ];

  return (
    <section className="py-20 px-4 bg-muted/20">
      <div className="container mx-auto max-w-4xl">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gradient">
            La Nostra Musica
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Esplora le nostre creazioni musicali.
          </p>
        </div>

        {/* Top 3 Songs Podium */}
        <div className="mb-16">
          <h3 className="text-2xl font-display font-semibold mb-8 text-center text-gradient">
            Le Nostre Hit
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto">
            {/* Second Place */}
            <div className="md:order-1 order-2">
              <Card className="audio-player group h-full bg-gradient-to-br from-muted/30 to-muted/60">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-xl font-bold text-accent-foreground">2</span>
                  </div>
                  <img
                    src={songs[2].cover}
                    alt={songs[2].title}
                    className="w-20 h-20 rounded-lg object-cover mx-auto mb-4"
                  />
                  <h4 className="font-semibold text-foreground mb-2">{songs[2].title}</h4>
                  <p className="text-muted-foreground text-sm">{songs[2].artist}</p>
                </CardContent>
              </Card>
            </div>

            {/* First Place */}
            <div className="md:order-2 order-1">
              <Card className="audio-player group h-full bg-gradient-primary transform md:scale-110">
                <CardContent className="p-6 text-center text-primary-foreground">
                  <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-2xl font-bold">1</span>
                  </div>
                  <img
                    src={songs[0].cover}
                    alt={songs[0].title}
                    className="w-24 h-24 rounded-lg object-cover mx-auto mb-4"
                  />
                  <h4 className="font-semibold mb-2 text-lg">{songs[0].title}</h4>
                  <p className="text-primary-foreground/80 text-sm">{songs[0].artist}</p>
                </CardContent>
              </Card>
            </div>

            {/* Third Place */}
            <div className="md:order-3 order-3">
              <Card className="audio-player group h-full bg-gradient-to-br from-muted/20 to-muted/40">
                <CardContent className="p-6 text-center">
                  <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-4">
                    <span className="text-xl font-bold text-muted-foreground">3</span>
                  </div>
                  <img
                    src={songs[3].cover}
                    alt={songs[3].title}
                    className="w-20 h-20 rounded-lg object-cover mx-auto mb-4"
                  />
                  <h4 className="font-semibold text-foreground mb-2">{songs[3].title}</h4>
                  <p className="text-muted-foreground text-sm">{songs[3].artist}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* All Songs List */}
        <div className="mb-12">
          <h3 className="text-2xl font-display font-semibold mb-8 text-center text-gradient">
            Tutte le Nostre Canzoni
          </h3>
          <div className="space-y-6">
            {songs.map((song, index) => (
              <Card key={song.id} className="audio-player group">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    {/* Album Cover & Play Button */}
                    <div className="relative flex-shrink-0">
                      <img
                        src={song.cover}
                        alt={song.title}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <button
                        onClick={() => togglePlay(song.id, index)}
                        className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      >
                        {currentlyPlaying === song.id ? (
                          <Pause className="h-6 w-6 text-white" />
                        ) : (
                          <Play className="h-6 w-6 text-white ml-1" />
                        )}
                      </button>
                    </div>

                    {/* Song Info */}
                    <div className="flex-grow">
                      <h3 className="font-semibold text-foreground text-lg">
                        {song.title}
                      </h3>
                      <p className="text-muted-foreground">
                        {song.artist} • {song.duration}
                      </p>
                    </div>

                    {/* Streaming Links */}
                    <div className="flex gap-2">
                      {streamingPlatforms.map((platform) => (<>
                        {song.streamingLinks[platform.key] != null &&
                          <Button
                            key={platform.name}
                            variant="outline"
                            size="sm"
                            asChild
                            className="hover:bg-primary hover:text-primary-foreground"
                          >
                            <a
                              href={song.streamingLinks[platform.key]}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2"
                            >
                              <span>{platform.icon}</span>
                              <span className="hidden sm:inline">{platform.name}</span>
                              <ExternalLink className="h-3 w-3" />
                            </a>
                          </Button>
                        }
                      </>))}
                    </div>
                  </div>

                  {/* Hidden Audio Element for Demo */}
                  <audio
                    ref={(el) => audioRefs.current[index] = el}
                    onEnded={() => setCurrentlyPlaying(null)}
                    preload="none"
                  >
                    {/* In a real app, you'd have actual audio files */}
                    <source src={song.audioUrl} type="audio/mp3" />
                  </audio>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <p className="text-muted-foreground mb-6">
            Ascolta la nostra musica completa sulle principali piattaforme streaming
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            {streamingPlatforms.map((platform) => (
              <Button
                key={platform.name}
                variant="outline"
                // className="btn-hero"
                asChild
              >
                <a
                  href="#"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2"
                >
                  <span>{platform.icon}</span>
                  Seguici su {platform.name}
                  <ExternalLink className="h-4 w-4" />
                </a>
              </Button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Music;