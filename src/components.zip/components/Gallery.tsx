import { useState } from 'react';
import { ChevronLeft, ChevronRight, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import groupPhoto1 from '@/assets/gruppo/bane_come_beatles.jpg';
import groupPhoto2 from '@/assets/gruppo/culoni.jpg';
import member1 from '@/assets/persone_occhiali/pac_occhiali.jpg';
import member2 from '@/assets/persone_occhiali/pacjo_occhiali.jpg';
import member3 from '@/assets/persone_occhiali/senpai_occhiali.jpg';
import member4 from '@/assets/persone_occhiali/gabubag_occhiali.jpg';
import member5 from '@/assets/persone_occhiali/luca_occhiali.jpg';
import member6 from '@/assets/persone_occhiali/buz_occhiali.jpg';
import member7 from '@/assets/persone_occhiali/axel_occhiali.jpg';
import project1 from '@/assets/project1.jpg';
import album1 from '@/assets/album1.jpg';

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  const images = [
    { src: groupPhoto1, alt: "BaNe come Beatles", category: "group" },
    { src: groupPhoto2, alt: "BaNe culoni", category: "group" },
    { src: member1, alt: "Membro del team", category: "members" },
    { src: member2, alt: "Membro del team", category: "members" },
    { src: member3, alt: "Membro del team", category: "members" },
    { src: member4, alt: "Membro del team", category: "members" },
    { src: member5, alt: "Membro del team", category: "members" },
    { src: member6, alt: "Membro del team", category: "members" },
    { src: member7, alt: "Membro del team", category: "members" },
    // { src: project1, alt: "Progetto realizzato", category: "projects" },
    // { src: album1, alt: "Album cover", category: "music" }
  ];

  const nextImage = () => {
    if (selectedImage !== null) {
      setSelectedImage((selectedImage + 1) % images.length);
    }
  };

  const prevImage = () => {
    if (selectedImage !== null) {
      setSelectedImage(selectedImage === 0 ? images.length - 1 : selectedImage - 1);
    }
  };

  return (
    <section className="py-20 px-4 bg-muted/20">
      <div className="container mx-auto max-w-6xl">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gradient">
            Galleria
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Una raccolta dei nostri momenti più belli e dei progetti che ci rendono orgogliosi.
          </p>
        </div>

        {/* Image Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {images.map((image, index) => (
            <Card 
              key={index} 
              className="gallery-item group cursor-pointer overflow-hidden"
              onClick={() => setSelectedImage(index)}
            >
              <CardContent className="p-0">
                <div className="relative aspect-square overflow-hidden">
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute bottom-4 left-4 right-4 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <p className="text-sm font-medium capitalize">
                      {image.category.replace('_', ' ')}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Modal */}
        {selectedImage !== null && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 p-4">
            <div className="relative max-w-4xl max-h-[90vh] w-full">
              <img
                src={images[selectedImage].src}
                alt={images[selectedImage].alt}
                className="w-full h-full object-contain"
              />
              
              {/* Close Button */}
              <Button
                variant="outline"
                size="sm"
                className="absolute top-4 right-4 bg-black/50 border-white/20 text-white hover:bg-black/70"
                onClick={() => setSelectedImage(null)}
              >
                <X className="h-4 w-4" />
              </Button>

              {/* Navigation */}
              <Button
                variant="outline"
                size="sm"
                className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/20 text-white hover:bg-black/70"
                onClick={prevImage}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 border-white/20 text-white hover:bg-black/70"
                onClick={nextImage}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>

              {/* Image Info */}
              <div className="absolute bottom-4 left-4 right-4 text-center">
                <p className="text-white bg-black/50 rounded-lg px-4 py-2 inline-block">
                  {images[selectedImage].alt}
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Gallery;